
public class CollectionObject {

}
